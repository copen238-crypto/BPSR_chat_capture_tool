from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, List, Tuple, Optional, Dict, Any
import re
import numpy as np

from .image import binarize_with_threshold
from .bubble import detect_chat_bubble_rects_auto, detect_message_rects
from .mask import apply_icon_mask_to_bins
from .ocr import ocr_string_from_bin, extract_scope_hint
from .parse import parse_text_multi, parse_text_with_scope_hint, parse_text_fallback_single

Rect = Tuple[int,int,int,int]

@dataclass
class PipelineSettings:
    ocr_scale: float = 1.0
    scope_threshold_high: int = 220
    body_threshold_low: int = 170

    use_bubble_rects: bool = True
    # icon mask (top-left) in original coordinates
    icon_mask_enabled: bool = True
    icon_mask_w: int = 24
    icon_mask_h: int = 26

    # scope ROI relative to each bubble (original coords)
    scope_roi_enabled: bool = False
    scope_roi_x: int = 0
    scope_roi_y: int = 28
    scope_roi_w: int = 180
    scope_roi_h: int = 26

@dataclass
class PipelineResult:
    messages: List[Dict[str,str]]
    rects: List[Rect]
    scope_rects: List[Rect]
    bin_prev: np.ndarray
    # for debugging
    used_fallback_single_rect: bool = False

def _sort_rects(rects: List[Rect]) -> List[Rect]:
    return sorted(rects, key=lambda r: (int(r[1]), int(r[0])))

def _clamp_rect(r: Rect, W: int, H: int) -> Optional[Rect]:
    x,y,w,h = [int(v) for v in r]
    x = max(0, x); y = max(0, y)
    w = max(1, w); h = max(1, h)
    x2 = min(W, x+w); y2 = min(H, y+h)
    w2 = x2-x; h2 = y2-y
    if w2 < 10 or h2 < 10:
        return None
    return (x,y,w2,h2)

class OCRPipeline:
    def __init__(self, *, color_detector: Optional[Callable[..., List[Rect]]] = None):
        # Optional color/HSV detector callable(frame_bgr, vmin_override=..., smax_override=...)
        self.color_detector = color_detector

    def process(self, frame_bgr: np.ndarray, settings: PipelineSettings) -> PipelineResult:
        # Prepare base bin images for preview/detection (use scope/high threshold for preview like old behavior)
        bin_ocr_hi, bin_prev, s = binarize_with_threshold(frame_bgr, settings.scope_threshold_high, settings.ocr_scale)

        # Detect bubble rects (original coords)
        rects: List[Rect] = []
        if settings.use_bubble_rects:
            rects = detect_chat_bubble_rects_auto(frame_bgr, bin_prev, color_detector=self.color_detector)
        else:
            rects = detect_message_rects(bin_prev)

        rects = _sort_rects([r for r in (rects or []) if _clamp_rect(r, frame_bgr.shape[1], frame_bgr.shape[0])])

        used_fallback = False
        if not rects:
            H,W = frame_bgr.shape[:2]
            rects = [(0,0,W,H)]
            used_fallback = True

        all_msgs: List[Dict[str,str]] = []
        scope_rects: List[Rect] = []

        H0,W0 = frame_bgr.shape[:2]
        for r0 in rects:
            r = _clamp_rect(r0, W0, H0)
            if r is None:
                continue
            rx,ry,rw,rh = r
            bubble = frame_bgr[ry:ry+rh, rx:rx+rw]

            # per-bubble binarization
            b_hi, _, bs = binarize_with_threshold(bubble, settings.scope_threshold_high, settings.ocr_scale)
            b_lo, _, _ = binarize_with_threshold(bubble, settings.body_threshold_low, settings.ocr_scale)

            # icon mask on both
            if settings.icon_mask_enabled:
                mw = int(round(settings.icon_mask_w * bs))
                mh = int(round(settings.icon_mask_h * bs))
                apply_icon_mask_to_bins(b_hi, b_lo, mw, mh)

            # scope ROI (scaled coords inside b_hi)
            roi_scaled = None
            manual_scope_roi = False
            if settings.scope_roi_enabled and settings.scope_roi_w > 0 and settings.scope_roi_h > 0:
                x0 = int(max(0, round(settings.scope_roi_x * bs)))
                y0 = int(max(0, round(settings.scope_roi_y * bs)))
                x1 = int(min(b_hi.shape[1], round((settings.scope_roi_x + settings.scope_roi_w) * bs)))
                y1 = int(min(b_hi.shape[0], round((settings.scope_roi_y + settings.scope_roi_h) * bs)))
                if x1 - x0 >= 10 and y1 - y0 >= 10:
                    roi_scaled = (x0,y0,x1,y1)
                    manual_scope_roi = True
            if roi_scaled is None:
                # Auto fallback: near 2nd line left side, based on icon height
                # This is deliberately conservative; users can tune via the Scope tab.
                mh = int(round(settings.icon_mask_h * bs)) if settings.icon_mask_enabled else int(round(26 * bs))
                x0 = 0
                y0 = min(b_hi.shape[0]-1, max(0, mh + int(round(2*bs))))
                x1 = min(b_hi.shape[1], int(round(220 * bs)))
                y1 = min(b_hi.shape[0], y0 + int(round(28 * bs)))
                roi_scaled = (x0,y0,x1,y1)

            x0,y0,x1,y1 = roi_scaled
            # If user provided a manual scope ROI, treat that region as "scope only":
            # remove it from the low-threshold bin so the scope text won't leak into the body OCR.
            if manual_scope_roi:
                try:
                    b_lo[y0:y1, x0:x1] = 255
                except Exception:
                    pass
            roi_img = b_hi[y0:y1, x0:x1]
            raw_scope = ocr_string_from_bin(roi_img, psm=7)
            scope_hint = extract_scope_hint(raw_scope)
            if not scope_hint:
                raw_scope = ocr_string_from_bin(roi_img, psm=6)
                scope_hint = extract_scope_hint(raw_scope)

            # record scope rect for preview (absolute coords in original image space)
            try:
                ax0 = int(rx + (x0 / bs))
                ay0 = int(ry + (y0 / bs))
                aw = int((x1 - x0) / bs)
                ah = int((y1 - y0) / bs)
                if aw > 2 and ah > 2:
                    scope_rects.append((ax0, ay0, aw, ah))
            except Exception:
                pass

            # low OCR for speaker/body
            raw_low = ocr_string_from_bin(b_lo, psm=6)
            msgs = parse_text_multi(raw_low)
            if (not msgs) and scope_hint:
                msgs = parse_text_with_scope_hint(raw_low, scope_hint)
            if not msgs:
                msgs = parse_text_fallback_single(raw_low)

            # enforce scope from HIGH only; and strip scope prefix from content if needed
            if msgs:
                for mm in msgs:
                    mm["scope"] = scope_hint or ""
                    if scope_hint:
                        mm["content"] = re.sub(r"^\s*\[[^\]]+\]\s*", "", (mm.get("content") or "")).strip()
                all_msgs.extend(msgs)

        return PipelineResult(messages=all_msgs, rects=rects, scope_rects=scope_rects, bin_prev=bin_prev, used_fallback_single_rect=used_fallback)
