from __future__ import annotations
from typing import List, Tuple, Optional, Callable
import cv2
import numpy as np

Rect = Tuple[int,int,int,int]

def _clamp_rect(x:int,y:int,w:int,h:int,W:int,H:int)->Optional[Rect]:
    x = max(0, int(x)); y = max(0, int(y))
    w = int(w); h = int(h)
    if w <= 0 or h <= 0:
        return None
    x2 = min(W, x+w); y2 = min(H, y+h)
    w2 = x2-x; h2 = y2-y
    if w2 < 10 or h2 < 10:
        return None
    return (x,y,w2,h2)

def _split_rect_by_text_gaps(inv_text: np.ndarray, rect: Rect, *, min_gap_px: int = 6, min_seg_h: int = 22) -> List[Rect]:
    """Split a (possibly merged) rect using *text absence* horizontal gap bands.

    This complements the background-mask gap splitting. It works even when the space
    between two bubbles is bright (white) but contains no text.

    inv_text: inverted binary-like image where text pixels are >0.
    """
    H, W = inv_text.shape[:2]
    x, y, w, h = [int(v) for v in rect]
    sub = inv_text[y:y+h, x:x+w]
    if sub.size == 0:
        return [rect]

    row_sum = (sub > 0).sum(axis=1)
    # A row is considered a gap if it has very few text pixels
    gap = row_sum < max(1, int(w * 0.01))

    cuts: List[Tuple[int, int]] = []
    run_start: Optional[int] = None
    for i, is_gap in enumerate(gap):
        if is_gap and run_start is None:
            run_start = i
        elif (not is_gap) and run_start is not None:
            run_len = i - run_start
            if run_len >= min_gap_px:
                cuts.append((run_start, i))
            run_start = None
    if run_start is not None:
        run_len = len(gap) - run_start
        if run_len >= min_gap_px:
            cuts.append((run_start, len(gap)))

    if not cuts:
        return [rect]

    # Use cut midpoints, but keep segments large enough.
    cut_ys = [int((a + b) // 2) for a, b in cuts]
    segs: List[Rect] = []
    top = 0
    for cy in cut_ys:
        seg_h = cy - top
        if seg_h >= min_seg_h:
            segs.append((x, y + top, w, seg_h))
        top = cy
    if (h - top) >= min_seg_h:
        segs.append((x, y + top, w, h - top))

    out: List[Rect] = []
    for sx, sy, sw, sh in segs:
        rr = _clamp_rect(sx, sy, sw, sh, W, H)
        if rr:
            out.append(rr)
    return out or [rect]

def detect_message_rects(bin_img: np.ndarray) -> List[Rect]:
    """
    Detect per-message (chat bubble) rectangles from a *binarized* image (bg=255, text=0).

    This implementation mirrors the proven logic from the pre-modular (v95+) code:
      - Use the binarized image to detect *bubble/background* white regions (threshold > 200).
      - Avoid merging stacked bubbles by breaking thin bridges and splitting tall merged regions
        by finding horizontal "gap" bands.

    Returns list[(x,y,w,h)] in the same coordinate as bin_img.
    """
    try:
        if bin_img is None:
            return []
        img = bin_img
        if img.ndim == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        H, W = img.shape[:2]
        if H < 30 or W < 80:
            return []
        if img.dtype != np.uint8:
            img = img.astype(np.uint8)

        # Bubble/background should be white.
        _, mask = cv2.threshold(img, 200, 255, cv2.THRESH_BINARY)

        # Remove tiny specks.
        open_k = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, open_k, iterations=1)

        # Break thin bridges that connect stacked bubbles.
        sep_k = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 2))
        mask_sep = cv2.morphologyEx(mask, cv2.MORPH_OPEN, sep_k, iterations=1)

        # Inverted binary-like image where text pixels are >0 (used for additional gap splitting).
        # This helps split merged rectangles even when the space between bubbles is bright (white).
        inv_text = cv2.bitwise_not(img)

        def _split_once(x: int, y: int, rw: int, rh: int) -> List[Rect]:
            """Split one rectangle into two by finding the strongest horizontal gap band."""
            roi = mask_sep[y:y+rh, x:x+rw]
            if roi.size == 0 or rh < 40:
                return [(x, y, rw, rh)]

            row_white = (roi > 0).sum(axis=1)
            gap_thr = max(8, int(0.05 * rw))
            gaps = row_white < gap_thr

            best = None  # (len, start, end)
            i = 0
            while i < rh:
                if not gaps[i]:
                    i += 1
                    continue
                j = i
                while j < rh and gaps[j]:
                    j += 1
                seg_len = j - i
                # Ignore gaps too close to borders (bubble border lines).
                if seg_len >= 3 and i > 6 and j < rh - 6:
                    if best is None or seg_len > best[0]:
                        best = (seg_len, i, j)
                i = j

            if best is None:
                return [(x, y, rw, rh)]

            _, gs, ge = best
            cut = (gs + ge) // 2
            top = (x, y, rw, max(1, cut - 1))
            bot_h = rh - (cut + 1)
            bot = (x, y + cut + 1, rw, max(1, bot_h))

            if top[3] < 22 or bot[3] < 22:
                return [(x, y, rw, rh)]
            return [top, bot]

        def _split_recursive(x: int, y: int, rw: int, rh: int, depth: int = 0) -> List[Rect]:
            if depth >= 3:
                return [(x, y, rw, rh)]
            parts = _split_once(x, y, rw, rh)
            if len(parts) == 1:
                # If background-mask gaps are not visible (e.g. the chat window itself is bright),
                # try splitting by detecting horizontal bands with *no text*.
                if rh >= max(120, int(0.22 * H)):
                    tparts = _split_rect_by_text_gaps(inv_text, (x, y, rw, rh), min_gap_px=10, min_seg_h=26)
                    if len(tparts) > 1:
                        out2: List[Rect] = []
                        for (tx, ty, tw, th) in tparts:
                            out2.extend(_split_recursive(tx, ty, tw, th, depth + 1))
                        return out2
                return parts
            out: List[Rect] = []
            for (px, py, pw, ph) in parts:
                out.extend(_split_recursive(px, py, pw, ph, depth + 1))
            return out

        contours, _ = cv2.findContours(mask_sep, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        rects: List[Rect] = []
        min_area = max(600, int(0.0025 * W * H))
        max_area = int(0.90 * W * H)

        for c in contours:
            x, y, rw, rh = cv2.boundingRect(c)
            area = rw * rh
            if area < min_area or area > max_area:
                continue
            if rw < 80 or rh < 26:
                continue
            # Reject nearly full ROI (often the entire capture).
            if rw > 0.98 * W and rh > 0.70 * H:
                continue

            for (px, py, pw, ph) in _split_recursive(x, y, rw, rh):
                if pw < 80 or ph < 26:
                    continue
                pad = 2
                x0 = max(0, px - pad)
                y0 = max(0, py - pad)
                x1 = min(W, px + pw + pad)
                y1 = min(H, py + ph + pad)
                rr = _clamp_rect(x0, y0, x1 - x0, y1 - y0, W, H)
                if rr:
                    rects.append(rr)

        rects.sort(key=lambda r: (r[1], r[0]))

        # Safety: if we ended up with one huge rect, treat as failure
        if len(rects) == 1:
            x, y, rw, rh = rects[0]
            if (rw * rh) > (0.65 * W * H):
                return []

        return rects
    except Exception:
        return []

def detect_chat_bubble_rects_auto(frame_bgr: np.ndarray, bin_prev: np.ndarray, *, color_detector: Optional[Callable]=None, vmin_override=None, smax_override=None) -> List[Rect]:
    """
    Auto policy:
    - Prefer binary-based rects (more stable across themes).
    - If no rects found, optionally try a color/HSV detector.
    """
    try:
        rects = detect_message_rects(bin_prev) if bin_prev is not None else []
        if rects:
            return rects
        if callable(color_detector):
            return color_detector(frame_bgr, vmin_override=vmin_override, smax_override=smax_override) or []
        return []
    except Exception:
        return []
